def parser_test():
	print('parser')