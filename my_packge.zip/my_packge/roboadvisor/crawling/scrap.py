# 절대경로
# from roboadvisor.database.connection import connection_test

# .. 상대경로
from ..database.connection import connection_test
def scrap_test():
	print('scrap')
	connection_test()