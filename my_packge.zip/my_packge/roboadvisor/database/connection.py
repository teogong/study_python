def connection_test():
	print('connection')